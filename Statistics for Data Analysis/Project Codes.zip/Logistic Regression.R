#Relevant packages
install.packages(c("ggplot2", "ggthemes", "GGally", "scales")) #For EDAs
install.packages("dplyr") #For data manipulation and wrangling
install.packages(c("lmtest", "car")) #For performing diagnostics and hypothesis tests on linear models
install.packages("data.table") #Handles large datasets with high performance
install.packages(c("Amelia", "mice")) #Handles missing data
install.packages("corrplot") #For visualizing correlation matrices.
install.packages(c("Metrics", "MLmetrics")) #Offers collection of evaluation metrics used in statistical analysis
install.packages("ISLR")
install.packages("performance")
install.packages("pROC") #To draw the ROC plot
install.packages("modEvA")
install.packages("ROSE") #For sampling
install.packages("rms")
install.packages("ResourceSelection")

#Libraries
library(Amelia)
library(Metrics)
library(ggplot2)
library(GGally)
library(car)
library(ISLR)
library(corrplot)
library(performance)
library(pROC)
library(caret)
library(modEvA) #Compute the R-squared
library(ROSE) #For sampling
library(rms) #For R-Squared evaluation
library(ResourceSelection)

#Import the dataset
setwd("C:\\Users\\topeo\\OneDrive\\Desktop\\Masters\\NCI\\Stats for Data Analytics\\CA2")

#Read the dataset & convert target variable to a factor
cardiac <- read.csv("cardiac.csv", header = TRUE, na.string=c(""), stringsAsFactors = T)
summary(cardiac)

############### DATA PRE-PROCESSING #################
#Data Analysis : Check for missing values
missing_values <- colSums(is.na(cardiac))
print(missing_values)

#### Logistic regression #### Small number of predictors are suitable
#### Parsimony ##### Remove "caseno" variable as it's irrelevant to the model
cardiac <- subset(cardiac, select = -c(caseno))
summary(cardiac)

#### One-Hot encode categorical variables
cardiac <- cbind(cardiac, model.matrix(~ gender - 1, data = cardiac))
cardiac <- cardiac[, -which(names(cardiac) %in% c("gender"))]
summary(cardiac)

#### Exploratory Data Analysis (EDA)
### Target variable distribution
barplot(table(cardiac$cardiac_condition), col = c("blue", "red"), main = "Distribution of Target Variable")
table(cardiac$cardiac_condition)

#### Balance the distribution of the target variable
cardiac_balanced <- ROSE(cardiac_condition ~ ., data = cardiac, seed = 200, N = 2 * sum(cardiac$cardiac_condition == "Absent"), p = 0.5)$data
barplot(table(cardiac_balanced$cardiac_condition), col = c("blue", "red"), main = "Distribution of Target Variable")
table(cardiac_balanced$cardiac_condition)
summary(cardiac_balanced)

#### Outlier analysis
### Box plot to visualize outliers in the variables
par(mfrow = c(2,3))
boxplot(cardiac_balanced$age, col = c("red"), main = "Box Plot of age")
boxplot(cardiac_balanced$weight, col = c("red"), main = "Box Plot of weight")
boxplot(cardiac_balanced$fitness_score, col = c("red"), main = "Box Plot of fitness score")
boxplot(cardiac_balanced$genderFemale, col = c("red"), main = "Box Plot of gender(Female)")
boxplot(cardiac_balanced$genderMale, col = c("red"), main = "Box Plot of gender(Male)")
par(mfrow = c(1,1))

#### IQR test to detect and remove outliers
cardiac_vars <- c("age", "weight", "fitness_score", "genderFemale", "genderMale")

for (variables in cardiac_vars) 
{
  q1 <- quantile(cardiac_balanced[[variables]], 0.25)
  q3 <- quantile(cardiac_balanced[[variables]], 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  # Identify and remove outliers
  cardiac_balanced <- cardiac_balanced[!(cardiac_balanced[[variables]] < lower_bound | cardiac_balanced[[variables]] > upper_bound), ]
}

#### View variability after outlier removal
summary(cardiac_balanced)

### Box plot to visualize outliers in the variables (Post IQR test)
par(mfrow = c(2,3))
boxplot(cardiac_balanced$age, col = c("red"), main = "Box Plot of age")
boxplot(cardiac_balanced$weight, col = c("red"), main = "Box Plot of weight")
boxplot(cardiac_balanced$fitness_score, col = c("red"), main = "Box Plot of fitness score")
boxplot(cardiac_balanced$genderFemale, col = c("red"), main = "Box Plot of gender(Female)")
boxplot(cardiac_balanced$genderMale, col = c("red"), main = "Box Plot of gender(Male)")
par(mfrow = c(1,1))

### Relationships between Predictor Variables and Target Variable
par(mfrow = c(2,3))
boxplot(age ~ cardiac_condition, data = cardiac_balanced, col = c("blue", "red"), main = "Age vs. Target Variable")
boxplot(weight ~ cardiac_condition, data = cardiac_balanced, col = c("blue", "red"), main = "Weight vs. Target Variable")
boxplot(fitness_score ~ cardiac_condition, data = cardiac_balanced, col = c("blue", "red"), main = "Fitness Score vs. Target Variable")
boxplot(genderFemale ~ cardiac_condition, data = cardiac_balanced, col = c("blue", "red"), main = "Gender(Female) vs. Target Variable")
boxplot(genderMale ~ cardiac_condition, data = cardiac_balanced, col = c("blue", "red"), main = "Gender(Male) vs. Target Variable")
par(mfrow = c(1,1))

#### More Data Visualization 
## Density Plots to show distribution of predictors for each level of the target variable
ggplot(cardiac_balanced, aes(x = age, fill = cardiac_condition)) +
  geom_density(alpha = 0.8) +
  labs(title = "Density Plot of Age by Target Variable")

ggplot(cardiac_balanced, aes(x = weight, fill = cardiac_condition)) +
  geom_density(alpha = 0.8) +
  labs(title = "Density Plot of Weight by Target Variable")

ggplot(cardiac_balanced, aes(x = fitness_score, fill = cardiac_condition)) +
  geom_density(alpha = 0.8) +
  labs(title = "Density Plot of Fitness Score by Target Variable")

ggplot(cardiac_balanced, aes(x = genderFemale, fill = cardiac_condition)) +
  geom_density(alpha = 0.8) +
  labs(title = "Density Plot of Females by Target Variable")

ggplot(cardiac_balanced, aes(x = genderMale, fill = cardiac_condition)) +
  geom_density(alpha = 0.8) +
  labs(title = "Density Plot of Males by Target Variable")

## Visualize relationships between predictors via Pair Plot
ggpairs(cardiac_balanced[, c("age", "weight", "fitness_score", "genderFemale", "genderMale", "cardiac_condition")],
        title = "Pair Plot of Numeric Predictors by Target Variable")

#### Normalize predictor variables
#### Min-max function
min_max_transform <- function(x) { return((x - min(x)) / (max(x) - min(x))) }

predictor_vars <- c("age", "weight", "fitness_score", "genderFemale", "genderMale")

#### Apply min-max function to each predictor variable
for (variable in predictor_vars)
{ cardiac_balanced[[variable]] <- min_max_transform(cardiac_balanced[[variable]]) }

summary(cardiac_balanced)

############################## Logistic Regression Model #####################################
set.seed(23187204) #Create reproducible results

#### Split the data into training and testing data
data_split <- createDataPartition(cardiac_balanced$cardiac_condition, p = 0.7, list = FALSE)

train_data = cardiac_balanced[data_split, ]
test_data = cardiac_balanced[-data_split, ]

#### Fit the model
lg_model <- glm(cardiac_condition ~ ., data = train_data, family = "binomial")
summary(lg_model)

##### Perform step-wise regression ##############
lg_stepwise <- step(lg_model, direction = "backward")
summary(lg_stepwise)

##### Assessing the model
### Check for collinearity
lg_model_vif <- vif(lg_stepwise)
print(lg_model_vif)
check_collinearity(lg_stepwise)

### Hosmer & Lemshow Test
performance_hosmer(lg_stepwise, n_bins = 10) #0.508

### Deviance
deviance <- summary(lg_stepwise)$deviance
print(paste("Deviance: ", deviance))

### Pseudo R-Squared (Cox & Snell, Negelkerie)
RsqGLM(model = lg_stepwise)

### Examine residuals for patterns, and heteroscedaticty
residuals <- resid(lg_stepwise, type = "deviance")
plot(predict(lg_stepwise, type = "response"), residuals, 
     main = "Residuals vs. Fitted", xlab = "Fitted Values", ylab = "Deviance Residuals")

### Compare predicted probabilities with observed frequencies (in bins)
calibration_data <- data.frame(observed = test_data$cardiac_condition,
                               predicted = predict(lg_stepwise, newdata = test_data, type = "response"))

ggplot(calibration_data, aes(predicted, fill = factor(observed))) +
  geom_histogram(position = "identity", alpha = 0.5, bins = 10) +
  labs(title = "Calibration Plot", x = "Predicted Probability", y = "Frequency")

########### Prediction on 30% testing subset
##### Evaluate model's performance
predictions <- ifelse(predict(lg_stepwise, newdata = test_data, type = "response") > 0.5, "Present", "Absent")

### Confusion Matrix
conf_matrix <- table(predictions, test_data$cardiac_condition)

#Calculate performance metrics
accuracy <- sum(diag(conf_matrix)) / sum(conf_matrix)
sensitivity <- conf_matrix["Present", "Present"] / sum(conf_matrix["Present", ])
specificity <- conf_matrix["Absent", "Absent"] / sum(conf_matrix["Absent", ])
ppv <- conf_matrix["Present", "Present"] / sum(conf_matrix[, "Present"])
npv <- conf_matrix["Absent", "Absent"] / sum(conf_matrix[, "Absent"])

#Print confusion matrix and performance metrics
print(conf_matrix)
cat("\n")
cat("Accuracy:", accuracy, "\n") #Accuracy: 0.7777778
cat("Sensitivity:", sensitivity, "\n") #Sensitivity: 0.8125 
cat("Specificity:", specificity, "\n") #Specificity: 0.75
cat("Positive Predictive Value (PPV):", ppv, "\n") #Positive Predictive Value (PPV): 0.7222222
cat("Negative Predictive Value (NPV):", npv, "\n") #Negative Predictive Value (NPV): 0.8333333

summary(train_data$cardiac_condition)
summary(test_data$cardiac_condition)

