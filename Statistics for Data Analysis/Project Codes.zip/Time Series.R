#Relevant packages
install.packages(c("ggplot2", "ggthemes", "GGally", "scales")) #For EDAs
install.packages("dplyr") #For data manipulation and wrangling
install.packages(c("lmtest", "car")) #For performing diagnostics and hypothesis tests on linear models
install.packages("data.table") #Handles large datasets with high performance
install.packages(c("Amelia", "mice")) #Handles missing data
install.packages("corrplot") #For visualizing correlation matrices.
install.packages(c("Metrics", "MLmetrics")) #Offers collection of evaluation metrics used in statistical analysis
install.packages("ISLR")
install.packages("performance")
install.packages("lubridate")
install.packages("tseries")
installed.packages("dplyr")

#Libraries
library(Amelia)
library(Metrics)
library(ggplot2)
library(car)
library(ISLR)
library(corrplot)
library(performance)
library(caret) #For cross-validation
library(forecast) #for forecasting 
library(lubridate)
library(tseries)
library(dplyr)

#Import the dataset
setwd("C:\\Users\\topeo\\OneDrive\\Desktop\\Masters\\NCI\\Stats for Data Analytics\\CA2") #Set the working directory

#Load series & view its structure
weather <- read.csv("weather_revised.csv", header = TRUE, na.string=c(""), stringsAsFactors = T)
str(weather)

#Convert date column to date format
weather$date <- dmy(weather$date) ##Reformatting using lubridate package
summary(weather)
str(weather)
class(weather$date) #Verify if data is in the appropriate format

## Extract date and my assigned variable
weather_vars <- weather[, c("date", "gmin.Grass.Minimum.Temperature...degrees.C.")]
str(weather_vars)

## Sort the data in chronological order
weather_vars <- weather_vars %>% arrange(date)
head(weather_vars)

#Verify date is in suitable format and is imported correctly
print(min(weather_vars$date))
print(max(weather_vars$date))

############### DATA PRE-PROCESSING #################
##Data Analysis : Check for missing values
missing_values <- is.na(weather_vars)
col_missing_counts <- colSums(missing_values)
col_missing_counts

###Handle missing values
#Remove missing values
weather_vars <- na.omit(weather_vars)
missing_values <- is.na(weather_vars)
col_missing_counts <- colSums(missing_values)
col_missing_counts

##Define start and end arguments of the time series
start_arg <- c(year(min(weather_vars$date)), month(min(weather_vars$date)))
start_arg

end_arg <- c(year(max(weather_vars$date)), month(max(weather_vars$date)))
end_arg


#### Exploratory Data Analysis (EDA)
## Box plot to visualize outlier in variable
boxplot(weather_vars$gmin.Grass.Minimum.Temperature...degrees.C., col = c("red"), main = "Box Plot of Grass Minimum Temperature")

#### IQR test to detect and remove outlier in variable
iqr_var <- c("gmin.Grass.Minimum.Temperature...degrees.C.")

for (variable in iqr_var) 
{
  q1 <- quantile(weather_vars[[variable]], 0.25)
  q3 <- quantile(weather_vars[[variable]], 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  # Identify and remove outliers
  weather_vars <- weather_vars[!(weather_vars[[variable]] < lower_bound | weather_vars[[variable]] > upper_bound), ]
}

#Post IQR test
boxplot(weather_vars$gmin.Grass.Minimum.Temperature...degrees.C., col = c("red"), main = "Box Plot of Grass Minimum Temperature")


### Define time series
#Frequency of 12 means each observation corresponds to a month
weather_ts <- ts(data = weather_vars$gmin.Grass.Minimum.Temperature...degrees.C.,
                 start = start_arg, #first observation
                 end = end_arg, #last observation
                 frequency = 12,) #series frequency

weather_ts

###### Assessment of raw time series
plot(weather_ts, type = "o", col = "darkorange", xlab = "Date", main = "Assessment of Time Series")
length(weather_ts) #982
head(weather_ts)

### Split time series into training and testing data
train <- window(weather_ts, start=c(2019, 1), end=c(2022, 12)) #Fit model using data from 2019-2022
test <- window(weather_ts, start = c(2023, 1), end=c(2023,10)) #Evaluate model using data from 2023

## Plot & assess the series 
autoplot(train, main = "Fitted model with data from 2019 - 2022", col = "darkorange", lwd = 1)
ggtsdisplay(train)
head(train)
length(train)

### Check if training data covers the required range
print(start(train))
print(end(train))
print(frequency(train))

## Check for stationarity
adf.test(train)  #pvalue is 0.01 (< 0.05) so reject null hypothesis
## Conclusion is that the time series is stationary

############## Simple Time-Series Model #############
#### Model 1: Average Method
fit_mean<-meanf(train, h = 7)
summary(fit_mean)
plot(fit_mean)
length(fit_mean)

#### Model 2: Naive Method (Random Walk)
fit_naive<-naive(train, h = 7)
summary(fit_naive)
plot(fit_naive)
length(fit_naive)

### Model 3: Season Naive Method
fit_seasonalnaive<-snaive(train, h = 7)
summary(fit_seasonalnaive)
plot(fit_seasonalnaive)
length(fit_seasonalnaive)

### Model 4: Drift Method
fit_drift <- rwf(train, h = 7, drift = TRUE)
summary(fit_drift)
plot(fit_drift)
length(fit_drift)

#### Performance metrics for simple time-series models
accuracy(fit_mean) #Evaluate Model 1: Average Method
accuracy(fit_naive) #Evaluate Model 2: Naive Method
accuracy(fit_seasonalnaive) #Evaluate Model 3: Seasonal Naive Method
accuracy(fit_drift) #Evaluate Model 4: Drift Method

#### Evaluate performance on 2023 data
### Evaluate on average model since it has lowest RMSE
test_avg <- meanf(test, h = 7)
accuracy(test_avg)


############## Exponential Smoothing Model #############
#Seasonal Decomposition
#Decompose into trend, seasonal and irregular components
#Ratio-to-moving average method
decomposition_ts <- decompose(weather_ts)
plot(decomposition_ts)

#Loess decomposition method
loess_decomp <- stl(weather_ts, s.window = "periodic") #Periodic is appropriate since there is constant seasonality
plot(loess_decomp)

#Assessing each components
trend_loess <- loess_decomp$time.series[, "trend"]
seasonal_loess <- loess_decomp$time.series[, "seasonal"]
irregular_loess <- loess_decomp$time.series[, "remainder"]

##Fit simple exponential smoothing model
ses_model <- ses(train, h = 7)
ses_model
round(accuracy(ses_model), 2)
autoplot(ses_model)+autolayer(fitted(ses_model), series = "Fitted")

##Fit double exponential smoothing model
holt_model <- holt(train, h = 7)
holt_model
round(accuracy(holt_model), 2)
autoplot(holt_model)+autolayer(fitted(holt_model), series = "Fitted")

##Fit triple exponential smoothing model
hw_model <- hw(train, h = 7)
hw_model
round(accuracy(hw_model), 2)
autoplot(hw_model)+autolayer(fitted(hw_model), series = "Fitted")

##Fit using ets function
#1. ANN
ann_model <- ets(train, model = "ANN")
ann_model
round(accuracy(ann_model), 2)

#2. AAN
aan_model <- ets(train, model = "AAN")
aan_model
round(accuracy(aan_model), 2)

#3. AAA
aaa_model <- ets(train, model = "AAA")
aaa_model
round(accuracy(aaa_model), 2)

##Fit model with ets function
expo_model <- ets(train, model = "ZZZ")
expo_model
round(accuracy(expo_model), 2)

### Evaluate the model
expo_test <- ets(test, model = "ZZZ")
expo_test
round(accuracy(expo_test), 2)
autoplot(expo_test)
autoplot(expo_test)+autolayer(fitted(expo_test),series = "Fitted")


############## ARIMA Model #############
#Determine required order of differencing
ndiffs(train)
#No differencing is required

#Plot series along with ACF and PACF functions
ggtsdisplay(train)

###AR order(p) is chosen based on the lag where the PACF plot cuts off.
###d is the order of differencing
###MA order(q) is chosen based on the lag where the ACF plot cuts off.

##ARIMA(1,0,1)
fit101 <- Arima(train, order = c(1,0,1))
summary(fit101) #AIC=248.15

##Fit close variations of this model
##ARIMA(1,0,0)
fit100 <- Arima(train, order = c(1,0,0))
summary(fit100) #AIC=246.44

##ARIMA(0,0,1)
fit001 <- Arima(train, order = c(0,0,1))
summary(fit001) #AIC=246.19

##ARIMA(0,0,0)
fit000 <- Arima(train, order = c(0,0,0))
summary(fit000) #AIC=247.37

##ARIMA(2,0,0)
fit200 <- Arima(train, order = c(2,0,0))
summary(fit200) #AIC=247.55

### Fit the ARIMA model
auto.arima(train) #AIC=246.19 (0,0,1)

##Diagnostics
### Check residuals
checkresiduals(fit001$residuals)

### Produce a forecast using the fitted model
predictions001 <- forecast::forecast(fit001, h = length(test))
autoplot(predictions001)

## Evaluation
round(accuracy(fit001), 3)

mae001 <- round(MAE(predictions001$mean, test), 3)
mape001 <- round(mape(predictions001$mean, test), 3)
cat(paste("ARIMA(0,0,1) -"," MAE:", mae001," MAPE:", mape001))
